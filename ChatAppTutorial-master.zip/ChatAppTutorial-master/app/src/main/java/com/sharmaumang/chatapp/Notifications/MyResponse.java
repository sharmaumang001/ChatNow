package com.sharmaumang.chatapp.Notifications;

public class MyResponse {

    public int success;
}
